import os
from time import sleep

while True:
    os.system('python /home/pi/Scripts/read_temp.py')
    sleep(60)
